To compile:
javac -cp .:InvertedIndexBase.jar SearchDemo.java

To run:
java -cp .:InvertedIndexBase.jar SearchDemo [anything = your code]
