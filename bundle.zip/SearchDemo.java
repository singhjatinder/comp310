

import info.derbinsky.wit.nate.NateInvertedIndexSearch;
import info.derbinsky.wit.nate.NateNaiveSearch;
import info.derbinsky.wit.primitives.LockableCorpus;
import info.derbinsky.wit.primitives.DocumentNameList;
import info.derbinsky.wit.primitives.SingleWordTextSearchEngine;
import info.derbinsky.wit.primitives.LockableWordList;
import info.derbinsky.wit.sources.SourceReader;

import java.io.IOException;

/**
 * Compares performance of a naive and inverted
 * index search engine on a set of query terms.
 */
public class SearchDemo {
	
	private static boolean checkResultSet(String word, DocumentNameList docs, int limit, LockableCorpus corpus) {
		
		if ( docs.numDocumentNames() > limit ) {
			return false;
		}
		
		for ( String doc : corpus.getDocumentNames() ) {
			
			final LockableWordList words = corpus.getDocumentWords( doc );
			
			if ( docs.containsDocumentName( doc ) ) {
				
				if ( !words.containsWord( word ) ) {
					return false;
				}
				
			} else {
				
				if ( ( docs.numDocumentNames() < limit ) && words.containsWord( word ) ) {
					return false;
				}
				
			}
			
		}

		return true;
		
	}
		
	private static Long performSearch(SingleWordTextSearchEngine searchEngine, String word, int limit, int numSearches, LockableCorpus corpus) {
		
		long start = System.currentTimeMillis();
		for ( int i=0; i<numSearches; i++ ) {
			
			final DocumentNameList docs = searchEngine.queryDocuments( word, limit );
			if ( corpus != null ) {
				
				if ( !checkResultSet( word, docs, limit, corpus ) ) {
					return null;
				}
				
			}
			
		}
		long end = System.currentTimeMillis();
		
		return ( end - start );
		
	}
	
	/**
	 * Compares a naive search with an inverted index
	 * 
	 * @param queries terms to use in the search
	 * @param limit max number of documents to return
	 * @param numSearches number of searches per query term
	 * @param nateVersion if true, pulls from .nate package, else .you
	 */
	public static void compareSearchAlgorithms(String[] queries, int limit, int numSearches, boolean nateVersion) {
		
		LockableCorpus corpus = null;
		try {
			corpus = SourceReader.readBenchmark( true );
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		//
		
		final SingleWordTextSearchEngine seNaive;
		final SingleWordTextSearchEngine seInvertedIndex;
		
		if ( nateVersion ) {
			seNaive = new NateNaiveSearch( corpus );
			seInvertedIndex = new NateInvertedIndexSearch( corpus );
		} else {
			seNaive = new NaiveSearch( corpus );
			seInvertedIndex = new InvertedIndexSearch( corpus );
		}
		
		final SingleWordTextSearchEngine[] engines = { seNaive, seInvertedIndex };
		
		//
		
		for ( SingleWordTextSearchEngine engine : engines ) {
			
			System.out.println( "== " + engine.getClass().getSimpleName() + " ==" );
			
			for ( String query : queries ) {
				
				System.out.print( " " + query + ": " );
				
				if ( performSearch( engine, query, limit, 1, corpus ) != null ) {
					System.out.println( performSearch( engine, query, limit, numSearches, null ) + " milliseconds for " + numSearches + " queries" );
				} else {
					System.out.println( "failed." );
				}
				
			}
			
			System.out.println();
			
		}
		
	}

	public static void main(String[] args) {
		
		final boolean nateVersion = ( args.length == 0 );
		
		final String[] queries = { "prince", "plantation", "queen", "clue", "fakewordismology" };
		final int limit = 3;
		final int numSearches = 50000;
		
		//
		
		compareSearchAlgorithms( queries, limit, numSearches, nateVersion );
		
	}

}
