

import info.derbinsky.wit.primitives.LockableCorpus;
import info.derbinsky.wit.primitives.DocumentNameList;
import info.derbinsky.wit.primitives.InvertedIndex;
import info.derbinsky.wit.primitives.SingleWordTextSearchEngine;


public class InvertedIndexSearch extends SingleWordTextSearchEngine {
	
	final private InvertedIndex index = new InvertedIndex();

	public InvertedIndexSearch(LockableCorpus documents) {
		super( documents );
		
		// do stuff?
		
	}

	@Override
	public DocumentNameList queryDocuments(String word, int limit) {
		
		final DocumentNameList docs = new DocumentNameList();
		
		// do stuff?
		
		return docs;
		
	}

}
