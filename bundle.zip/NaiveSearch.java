

import info.derbinsky.wit.primitives.LockableCorpus;
import info.derbinsky.wit.primitives.DocumentNameList;
import info.derbinsky.wit.primitives.SingleWordTextSearchEngine;


public class NaiveSearch extends SingleWordTextSearchEngine {

	public NaiveSearch(LockableCorpus documents) {
		super( documents );
		
		// do stuff?
		
	}

	@Override
	public DocumentNameList queryDocuments(String word, int limit) {
		
		final DocumentNameList docs = new DocumentNameList();
		
		// do stuff?
		
		return docs;
		
	}

}
